#Wed Nov 17 15:51:56 GMT 2021
dev/spi/ibm/com.ibm.websphere.appserver.spi.logging_1.1.59.jar=edcf55b9e2271197a01e108a104d13d7
lib/platform/defaultLogging-1.0.mf=5dca00ad3a1c72fd06670dc28717f34f
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.logging_1.1-javadoc.zip=549f189badef0f3b36955c30033b10c2
lib/com.ibm.ws.collector.manager_1.0.59.jar=4452646eea6b84a19b6d068430b3e8c5
lib/com.ibm.ws.logging.osgi_1.0.59.jar=c8014c90eaec5a2504680a0a1c80ef1d
lib/com.ibm.ws.logging_1.0.59.jar=2dce4dbeac03e1d5e1343f000ea73e0b
